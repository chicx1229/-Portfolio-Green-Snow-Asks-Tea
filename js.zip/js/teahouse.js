(function($){
    $.fn.teahouse = function(op){
        return this.each(function(){
            var oCarousel = $(this);
            var leftBtn = oCarousel.find('.leftBtn'); 
            var rightBtn = oCarousel.find('.rightBtn'); 
            var list = oCarousel.find('.list'); 
            var lis = list.find('li'); 
            var num = 0; 
            var lock = true;

            rightBtn.on('click', function(){
                if(!lock) return; // 如果锁定状态，则返回
                lock = false;
                lis.eq(num).css('opacity', 0); // 隐藏当前图片
                num = (num + 1) % lis.length; // 计算下一张图片的索引
                lis.eq(num).css('opacity', 1); // 显示下一张图片
                setTimeout(function(){
                    lock = true; // 在一定时间后解除锁定状态
                }, 500);
            });

            leftBtn.on('click', function(){
                if(!lock) return; // 如果锁定状态，则返回
                lock = false;
                lis.eq(num).css('opacity', 0); // 隐藏当前图片
                num = (num - 1 + lis.length) % lis.length; // 计算上一张图片的索引
                lis.eq(num).css('opacity', 1); // 显示上一张图片
                setTimeout(function(){
                    lock = true; // 在一定时间后解除锁定状态
                }, 500);
            });
        });
    }
})(jQuery);

$(document).ready(function(){
    $('#carousel').teahouse(); // 初始化teahouse插件
});